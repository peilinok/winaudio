import csv
import hashlib
import itertools
import json
import statistics
from pathlib import Path

ROOT = Path('build/performance-vs18')
FROZEN = '4EC3DFBAF134D8ABBE4BB2AA1A0FA293CABFEAC1F9EA5D56CF113948792DA5D9'
EXPECTED = {
    (1000, 2): '6BD6105FE896C39D681B083614F3C4BCFB822594794474879BDB2AFDBB62549F',
    (10000, 2): 'B7006AEFFB8AB782F37C4B8E960910750E81C2B5FF636D12F24B40A8E8AE3D4F',
    (10000, 1): '9A77A9859421770A48C67A2565A997ADE688CBAA5A65C0FDB6D178B48876C71F',
}


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def processes(path, warmup):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        rows = [{k: float(v) for k, v in r.items()} for r in csv.DictReader(stream)]
    rows = [r for r in rows if r['elapsed_s'] >= warmup]
    intervals = [b['elapsed_s'] - a['elapsed_s'] for a, b in zip(rows, rows[1:])]
    minutes = []
    for index in range(10):
        values = [r for r in rows if index * 60 <= r['elapsed_s'] - warmup < (index + 1) * 60]
        if values:
            minutes.append(dict(minute=index + 1, samples=len(values), **{
                key: dict(mean=statistics.mean(r[key] for r in values), maximum=max(r[key] for r in values))
                for key in ('private_bytes', 'working_set')}))
    return dict(samples=len(rows), seconds=rows[-1]['elapsed_s']-rows[0]['elapsed_s'],
                cpu_ms_per_s=(rows[-1]['cpu_ms']-rows[0]['cpu_ms'])/(rows[-1]['elapsed_s']-rows[0]['elapsed_s']),
                interval_mean=statistics.mean(intervals), interval_max=max(intervals),
                intervals_over_one_second=sum(x > 1.0 for x in intervals),
                memory={key: dict(minimum=min(r[key] for r in rows), maximum=max(r[key] for r in rows))
                        for key in ('private_bytes', 'working_set')}, minutes=minutes)


def export_check(folder):
    exported = folder / 'fixture-export.jsonl'
    if not exported.exists():
        return None
    parameter_hash = hashlib.sha256()
    sources = {}
    count = 0
    with (folder / 'fixture-input.jsonl').open(encoding='utf-8') as before, exported.open(encoding='utf-8') as after:
        for index, (left, right) in enumerate(itertools.zip_longest(before, after), 1):
            assert left is not None and right is not None, (folder.name, index, 'record count')
            expected, actual = json.loads(left), json.loads(right)
            identity = {key: actual.pop(key) for key in ('roundId', 'attachId', 'lane', 'sequence')}
            assert expected == actual, (folder.name, index, 'changed original content')
            assert identity == dict(roundId=1, attachId=1 if actual['pid'] == 42001 else 2,
                                    lane='control', sequence=index), (folder.name, index, identity)
            assert len(actual['parameters']) == 16, (folder.name, index, 'parameter count')
            parameter_hash.update(json.dumps(actual['parameters'], ensure_ascii=False, sort_keys=True).encode('utf-8'))
            sources[actual['pid']] = sources.get(actual['pid'], 0) + 1
            count += 1
    assert count == 10000
    return dict(records=count, pids=sources, parameters_per_record=16,
                parameter_tree_sha256=parameter_hash.hexdigest(),
                file_sha256=hashlib.sha256(exported.read_bytes()).hexdigest(), bytes=exported.stat().st_size)


result = {}
for collection in ('inspector-after', 'inspector-memory-acceptance'):
    output = []
    for folder in sorted((ROOT / collection).iterdir()):
        if not folder.is_dir():
            continue
        config = load(folder / 'config.json')
        assert config['executable_sha256'] == FROZEN, folder.name
        setting = config['configuration']
        summary_path = folder / 'summary.json'
        groups = []
        if summary_path.exists():
            summary = load(summary_path)
            assert summary['run_complete'] and summary['pending_operations_at_end'] == 0, folder.name
            for g in summary['groups']:
                if g['stage'] not in ('warmup', 'teardown', 'transition'):
                    assert g['frame_budget_met'] is not False, (folder.name, 'frame budget')
                    assert g['operation_budget_met'] is not False, (folder.name, 'operation budget')
                    groups.append(g)
        else:
            assert setting.get('probe') == 'off', folder.name
        fixture = folder / 'fixture-input.jsonl'
        if fixture.exists():
            assert hashlib.sha256(fixture.read_bytes()).hexdigest().upper() == EXPECTED[(setting['records'], setting['pids'])], folder.name
        output.append(dict(name=folder.name, groups=groups, process=processes(folder / 'process.csv', setting['warmup']),
                           export=export_check(folder), config=config))
    result[collection] = output
assert len(result['inspector-after']) == 21
assert len(result['inspector-memory-acceptance']) == 2
destination = ROOT / 'inspector-acceptance-analysis.json'
destination.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('Verified 21 formal runs, 2 memory resamples, fixed inputs and 3 complete exports:', destination)
