"""Archive manual GUI evidence and final verification, not budget samples."""
import gzip
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[2]
source = root / 'build/performance-vs18'
destination = root / 'docs/measurements/performance-acceptance/gui-checks/artifacts'
destination.mkdir(parents=True, exist_ok=True)
manifest = {}

def digest(path, compressed=False):
    result = hashlib.sha256()
    opener = gzip.open if compressed else open
    with opener(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()

def archive(path, label):
    target = destination / label
    before = digest(path)
    with path.open('rb') as stream, target.open('wb') as output:
        with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as zipped:
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                zipped.write(block)
    if digest(target, True) != before or digest(path) != before:
        raise ValueError('Archive verification failed: ' + str(path))
    manifest[str(path)] = {'artifact':label, 'source_sha256':before,
                           'content_sha256':before,'artifact_sha256':digest(target),
                           'source_bytes':path.stat().st_size,'artifact_bytes':target.stat().st_size}

def integrity(path):
    runs=[]
    current=None
    for line in path.open(encoding='utf-8-sig'):
        if '# WinAudio frame probe' in line:
            if current is not None and not line.startswith('# WinAudio frame probe'):
                current['truncated_before_next_header']=True
            current={'frames':0,'first_frame':None,'last_frame':None,'frame_gaps':0,
                     'lost_slices':0,'lost_operations':0,'lost_work':0,'lost_frames':0,
                     'complete':False,'pending_operations_at_end':None}
            runs.append(current)
        elif line.startswith('# End frame probe'):
            fields=dict(w.split('=',1) for w in line.split() if '=' in w)
            current['complete']=fields.get('complete')=='1' and int(fields['frame'])==current['last_frame']
        elif line.startswith('kind=frame '):
            fields=dict(w.split('=',1) for w in line.split() if '=' in w)
            frame=int(fields['frame'])
            if current['last_frame'] is not None and current['last_frame']+1!=frame:
                current['frame_gaps']+=1
            if current['first_frame'] is None:current['first_frame']=frame
            current['last_frame']=frame
            current['frames']+=1
            for field in ('lost_slices','lost_operations','lost_work','lost_frames'):
                current[field]+=int(fields[field])
            current['pending_operations_at_end']=int(fields['pending_operations'])
    return runs

folders=('charts-gui-final','monitor-gui-final','gui-wait-idle','gui-cancel',
         'gui-export-fail','gui-live-export','gui-production-boundaries',
         'charts-pan-final','monitor-nonzero-final')
runs={}
for folder in folders:
    directory=source/folder
    runs[folder]=integrity(directory/'frames.txt')
    for name in ('config.json','summary.json','frames.txt','winaudio.log',
                 'targets.txt','targets-error.txt','signal-out.txt','signal-error.txt'):
        path=directory/name
        if path.exists():archive(path,folder+'-'+name+'.gz')
    print(folder,json.dumps(runs[folder]))

export_folder=Path('C:/Users/peili/AppData/Local/WinAudio/pipeline-calls')
for name in ('calls-multi-20261024-142214-19516-256479765-0.jsonl',
             'calls-pid26324-20261024-162207-25932-263672593-0.jsonl'):
    archive(export_folder/name,name+'.gz')

for directory in (source,root/'build/performance-vs18-verify'):
    selected=set()
    for pattern in ('*red*.xml','*green*.xml','*red*.log','*green*.log',
                    '*acceptance*.log','*completion*.log','gui-boundary-*.log',
                    'envelope-timing-isolated.log'):
        selected.update(directory.glob(pattern))
    for path in sorted(selected):
        if path.name not in ('archive-completion.log','verify-inspector-acceptance.log'):
            archive(path,directory.name+'-'+path.name+'.gz')
for name in ('verify-inspector-acceptance.py','analyze-tail-growth.py',
             'verify-inspector-acceptance.log','inspector-acceptance-analysis.json',
             'archive-completion.py'):
    archive(source/name,name+'.gz')

(destination/'integrity.json').write_text(json.dumps(runs,indent=2)+'\n',encoding='utf-8')
(destination/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('verified artifacts',len(manifest))
