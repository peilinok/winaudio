import csv, json, bisect
from pathlib import Path
base = Path('build/performance-vs18/inspector-after')
def load(path):
    frames, slices, ops, counts = {}, {}, [], {}
    for line in path.open(encoding='utf-8-sig'):
        fields = dict(w.split('=', 1) for w in line.split() if '=' in w)
        if 'frame' not in fields: continue
        f = int(fields['frame'])
        if fields.get('kind') == 'frame': frames[f] = fields
        elif 'slice' in fields: slices.setdefault(f,{})[fields['slice']] = int(fields['ticks']) / 10000.0
        elif fields.get('kind') == 'operation': ops.append(fields)
        elif fields.get('metric') == 'control-total': counts[f] = int(fields['value'])
    return frames,slices,ops,counts
frames,slices,ops,counts=load(base/'inspector-single-3/frames.txt')
worst=max(ops,key=lambda x:int(x['ticks']))
f=int(worst['frame'])
tail={'operation':worst,'frames':[{ 'meta':frames[i], 'slices_ms':slices[i]} for i in range(f-2,f+3)]}
growth=[]
for repeat in (1,2,3):
    folder=base/('inspector-append-'+str(repeat))
    frames,slices,ops,counts=load(folder/'frames.txt')
    ordered=sorted(frames)
    ticks=[int(frames[i]['start']) for i in ordered]
    rows=list(csv.DictReader((folder/'process.csv').open(encoding='utf-8-sig')))
    samples=[]
    for row in rows:
        idx=bisect.bisect_right(ticks,int(row['qpc_tick']))-1
        if idx<0:continue
        frame=ordered[idx]
        if frame not in counts:continue
        samples.append({'elapsed_s':float(row['elapsed_s']), 'frame':frame, 'records':counts[frame],
                        'private_bytes':int(row['private_bytes']), 'working_set':int(row['working_set']),
                        'frame_age_ms':(int(row['qpc_tick'])-ticks[idx])/10000.0})
    bands=[]
    for low,high in ((9000,9000),(9001,9249),(9250,9499),(9500,9749),(9750,9999),(10000,10000)):
        selected=[s for s in samples if low<=s['records']<=high and s['elapsed_s']>=30]
        bands.append({'records':[low,high],'samples':len(selected),
                      'private_min':min((s['private_bytes'] for s in selected),default=None),
                      'private_max':max((s['private_bytes'] for s in selected),default=None),
                      'working_set_min':min((s['working_set'] for s in selected),default=None),
                      'working_set_max':max((s['working_set'] for s in selected),default=None)})
    growth.append({'run':folder.name,'bands':bands,'samples':samples})
folder=base/'inspector-live'
frames,slices,ops,counts=load(folder/'frames.txt')
ordered=sorted(frames)
ticks=[int(frames[i]['start']) for i in ordered]
samples=[]
for row in csv.DictReader((folder/'process.csv').open(encoding='utf-8-sig')):
    idx=bisect.bisect_right(ticks,int(row['qpc_tick']))-1
    if idx<0 or ordered[idx] not in counts: continue
    samples.append({'elapsed_s':float(row['elapsed_s']), 'frame':ordered[idx],
                    'records':counts[ordered[idx]], 'private_bytes':int(row['private_bytes']),
                    'working_set':int(row['working_set'])})
minutes=[]
for minute in range(10):
    selected=[s for s in samples if 30+minute*60<=s['elapsed_s']<90+minute*60]
    minutes.append({'minute':minute+1,'samples':len(selected),
                    'records_first':selected[0]['records'],'records_last':selected[-1]['records'],
                    'private_min':min(s['private_bytes'] for s in selected),
                    'private_max':max(s['private_bytes'] for s in selected),
                    'working_set_min':min(s['working_set'] for s in selected),
                    'working_set_max':max(s['working_set'] for s in selected)})
frames,slices,ops,counts=load(Path('build/performance-vs18/gui-live-export/frames.txt'))
start=next(i for i,v in slices.items() if 'export-start' in v)
last=max(counts)
out={'tail':tail,'growth':growth,'live_growth':{'minutes':minutes,'samples':samples},
     'gui_live_export':{'start_frame':start,'start_records':counts[start],
                        'last_frame':last,'last_records':counts[last],
                        'counts_increased':counts[last]>counts[start]}}
Path('docs/measurements/performance-acceptance/inspector-growth-tail.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'tail':tail,'growth':[{'run':g['run'],'bands':g['bands']} for g in growth],
                  'live_growth':minutes,'gui_live_export':out['gui_live_export']},indent=2))
